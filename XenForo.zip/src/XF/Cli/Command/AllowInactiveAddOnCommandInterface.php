<?php

namespace XF\Cli\Command;

interface AllowInactiveAddOnCommandInterface
{
}
